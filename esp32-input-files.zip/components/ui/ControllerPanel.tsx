"use client";

import { useEffect } from "react";
import { Cpu, Keyboard, Unplug, Usb } from "lucide-react";
import { connectESP32, disconnectESP32, selectInput } from "@/game/input/controllerHub";
import { isWebSerialSupported } from "@/game/input/esp32/WebSerialTransport";
import { type ControllerStatus, type InputKind, useControllerStore } from "@/lib/state/controllerStore";

const STATUS_LABEL: Record<ControllerStatus, string> = {
  disconnected: "DISCONNECTED",
  connecting: "CONNECTING",
  connected: "CONNECTED",
};

const INPUT_LABEL: Record<InputKind, string> = { keyboard: "KEYBOARD", esp32: "ESP32" };

/** Input actually driving the car is always "ready"; for ESP32 that means the link is up. */
function useActiveInputReady() {
  const inputKind = useControllerStore((state) => state.inputKind);
  const status = useControllerStore((state) => state.status);
  return inputKind === "keyboard" || status === "connected";
}

/** Short, non-interactive indicator for the race HUD. */
export function ControllerBadge() {
  const inputKind = useControllerStore((state) => state.inputKind);
  const status = useControllerStore((state) => state.status);
  const linkMode = useControllerStore((state) => state.linkMode);
  const ready = useActiveInputReady();

  return (
    <div className="controller-badge" data-state={status}>
      <span className="controller-icon">{inputKind === "esp32" ? <Cpu size={17} /> : <Keyboard size={17} />}</span>
      <span>
        <strong>INPUT: {INPUT_LABEL[inputKind]}</strong>
        <small>
          ESP32 · {STATUS_LABEL[status]}
          {linkMode === "mock" ? " · SIMULATED" : ""}
        </small>
      </span>
      <span className="controller-check" data-ready={ready}>{ready ? "✓" : "•"}</span>
    </div>
  );
}

/** Compact one-line input indicator for the menu top bar. */
export function ControllerChip() {
  const inputKind = useControllerStore((state) => state.inputKind);
  const status = useControllerStore((state) => state.status);
  return (
    <div className="connection-state" data-state={inputKind === "esp32" ? status : "connected"}>
      <span className="status-dot" />INPUT: {INPUT_LABEL[inputKind]}
    </div>
  );
}

/** Connect / switch / simulate controls (menu + pause screen; needs a mouse click, so not shown mid-race). */
export default function ControllerPanel() {
  const inputKind = useControllerStore((state) => state.inputKind);
  const status = useControllerStore((state) => state.status);
  const linkMode = useControllerStore((state) => state.linkMode);
  const serialSupported = useControllerStore((state) => state.serialSupported);
  const message = useControllerStore((state) => state.message);
  const setSerialSupported = useControllerStore((state) => state.setSerialSupported);

  // Feature-detect after mount so server and client render the same markup.
  useEffect(() => setSerialSupported(isWebSerialSupported()), [setSerialSupported]);

  const connected = status === "connected";
  const connecting = status === "connecting";

  return (
    <section className="controller-panel" aria-label="Controller" data-state={status}>
      <div className="controller-panel-head">
        <span className="status-dot" />
        <strong>{STATUS_LABEL[status]}</strong>
        <span className="controller-panel-input">INPUT: {INPUT_LABEL[inputKind]}{linkMode === "mock" ? " · SIMULATED" : ""}</span>
      </div>

      <div className="controller-switch" role="group" aria-label="Input source">
        <button type="button" aria-pressed={inputKind === "keyboard"} onClick={() => selectInput("keyboard")}>
          <Keyboard size={12} /> KEYBOARD
        </button>
        <button
          type="button"
          aria-pressed={inputKind === "esp32"}
          disabled={!connected}
          title={connected ? undefined : "Connect an ESP32 first"}
          onClick={() => selectInput("esp32")}
        >
          <Cpu size={12} /> ESP32
        </button>
      </div>

      <div className="controller-actions">
        {connected ? (
          <button type="button" className="controller-button" onClick={() => void disconnectESP32()}>
            <Unplug size={12} /> DISCONNECT
          </button>
        ) : (
          <button
            type="button"
            className="controller-button controller-button-primary"
            disabled={connecting || !serialSupported}
            onClick={() => void connectESP32("serial")}
          >
            <Usb size={12} /> {connecting ? "CONNECTING..." : "CONNECT ESP32"}
          </button>
        )}
        {!connected && (
          <button
            type="button"
            className="controller-button"
            disabled={connecting}
            title="Feed simulated joystick data through the same parser, no hardware needed"
            onClick={() => void connectESP32("mock")}
          >
            SIMULATE
          </button>
        )}
      </div>

      {!serialSupported && !connected && (
        <p className="controller-note">Web Serial needs Chrome or Edge on https:// or localhost. SIMULATE still works.</p>
      )}
      {message && <p className="controller-note">{message}</p>}
    </section>
  );
}
