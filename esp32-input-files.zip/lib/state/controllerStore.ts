import { create } from "zustand";

export type InputKind = "keyboard" | "esp32";
export type ControllerStatus = "disconnected" | "connecting" | "connected";
export type ControllerLinkMode = "serial" | "mock";

type ControllerStore = {
  inputKind: InputKind;
  status: ControllerStatus;
  linkMode: ControllerLinkMode | null;
  serialSupported: boolean;
  /** Last connection problem / notice, shown in the controller panel. */
  message: string | null;
  setInputKind: (inputKind: InputKind) => void;
  setConnection: (status: ControllerStatus, linkMode: ControllerLinkMode | null, message?: string | null) => void;
  setSerialSupported: (supported: boolean) => void;
};

export const useControllerStore = create<ControllerStore>((set) => ({
  inputKind: "keyboard",
  status: "disconnected",
  linkMode: null,
  serialSupported: false,
  message: null,
  setInputKind: (inputKind) => set({ inputKind }),
  setConnection: (status, linkMode, message = null) => set({ status, linkMode, message }),
  setSerialSupported: (serialSupported) => set({ serialSupported }),
}));
