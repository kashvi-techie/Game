import { type ControllerControls, type ControllerInputSource, neutralControls } from "./ControllerInputSource";

export class InputManager {
  private active = false;

  constructor(private source: ControllerInputSource) {}

  get label() {
    return this.source.label;
  }

  /** Hot-swap the active source (keyboard <-> ESP32). The game keeps calling read() and never notices. */
  setSource(next: ControllerInputSource) {
    if (next === this.source) return;
    if (this.active) {
      this.source.stop();
      next.start();
    }
    this.source = next;
  }

  start() {
    if (this.active) return;
    this.source.start();
    this.active = true;
  }

  stop() {
    if (!this.active) return;
    this.source.stop();
    this.active = false;
  }

  read(): ControllerControls {
    return this.active ? this.source.read() : neutralControls;
  }
}
