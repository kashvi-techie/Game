import { useControllerStore, type InputKind } from "@/lib/state/controllerStore";
import { type ControllerInputSource } from "./ControllerInputSource";
import { ESP32InputSource, type ESP32LinkMode } from "./ESP32InputSource";
import { KeyboardInputSource } from "./KeyboardInputSource";

/**
 * Single place that owns the input sources. They live at module level (not inside React) because the
 * ESP32 serial connection must survive menu -> race -> pause transitions and must be opened from a click.
 *
 *   InputSource
 *   ├── KeyboardInputSource
 *   ├── ESP32InputSource
 *   └── MobileInputSource   (future: add here, plus an InputKind entry in controllerStore)
 */
const keyboardSource = new KeyboardInputSource();
const esp32Source = new ESP32InputSource();

export function getInputSource(kind: InputKind): ControllerInputSource {
  switch (kind) {
    case "esp32":
      return esp32Source;
    case "keyboard":
    default:
      return keyboardSource;
  }
}

// ESP32 connection status -> UI store.
esp32Source.setStatusListener((status, detail, mode) => {
  const store = useControllerStore.getState();
  const connectionLost = status === "disconnected" && store.inputKind === "esp32";

  store.setConnection(status, status === "disconnected" ? null : (mode ?? null), detail ?? null);

  if (status === "connected") store.setInputKind("esp32");
  // Never leave the player with a dead car: fall back to keyboard if the controller goes away mid-session.
  if (connectionLost) {
    store.setInputKind("keyboard");
    store.setConnection("disconnected", null, detail ? `${detail} - switched to keyboard` : "ESP32 disconnected - switched to keyboard");
  }
});

/** Call from a click handler: the serial port chooser requires a user gesture. */
export function connectESP32(mode: ESP32LinkMode) {
  return esp32Source.connect(mode);
}

export function disconnectESP32() {
  return esp32Source.disconnect();
}

/** ESP32 can only be selected while connected; keyboard is always available. */
export function selectInput(kind: InputKind) {
  const store = useControllerStore.getState();
  if (kind === "esp32" && store.status !== "connected") return;
  store.setInputKind(kind);
}
