import { type ControllerControls, type ControllerInputSource, neutralControls } from "./ControllerInputSource";
import {
  DEFAULT_JOYSTICK_CALIBRATION,
  type JoystickCalibration,
  joystickToInputState,
  parseControllerLine,
} from "./esp32/esp32Protocol";
import type { LineTransport, TransportStatus } from "./esp32/LineTransport";
import { MockTransport } from "./esp32/MockTransport";
import { WebSerialTransport } from "./esp32/WebSerialTransport";

/** If no valid sample arrives for this long (board reset, cable wobble) the car gets neutral input, not stuck input. */
const STALE_AFTER_MS = 500;

export type ESP32LinkMode = "serial" | "mock";
export type ESP32StatusListener = (status: TransportStatus, detail?: string, mode?: ESP32LinkMode) => void;

/**
 * InputSource backed by an ESP32. It owns the connection (serial or mock) and exposes the latest
 * joystick reading as a normalized InputState. Connection lifetime is independent of start()/stop():
 * those only follow the race phase, while the serial link stays open across pause/menu.
 */
export class ESP32InputSource implements ControllerInputSource {
  readonly label = "ESP32";

  private transport: LineTransport | null = null;
  private latest: ControllerControls = neutralControls;
  private lastSampleAt = -Infinity;
  private connected = false;
  private statusListener: ESP32StatusListener | null = null;

  constructor(private readonly calibration: JoystickCalibration = DEFAULT_JOYSTICK_CALIBRATION) {}

  setStatusListener(listener: ESP32StatusListener | null) {
    this.statusListener = listener;
  }

  start() {}

  stop() {
    this.latest = neutralControls;
  }

  read(): ControllerControls {
    if (!this.connected || performance.now() - this.lastSampleAt > STALE_AFTER_MS) return neutralControls;
    return this.latest;
  }

  async connect(mode: ESP32LinkMode) {
    if (this.transport) await this.disconnect();

    const handlers = {
      onLine: (line: string) => this.handleLine(line),
      onStatus: (status: TransportStatus, detail?: string) => this.handleStatus(status, detail, mode),
    };
    this.transport = mode === "mock" ? new MockTransport(handlers) : new WebSerialTransport(handlers);
    await this.transport.connect();
  }

  async disconnect() {
    const transport = this.transport;
    this.transport = null;
    await transport?.disconnect();
  }

  private handleLine(line: string) {
    const sample = parseControllerLine(line);
    if (!sample) return; // boot logs, partial lines, junk
    this.latest = joystickToInputState(sample, this.calibration);
    this.lastSampleAt = performance.now();
  }

  private handleStatus(status: TransportStatus, detail: string | undefined, mode: ESP32LinkMode) {
    this.connected = status === "connected";
    if (status !== "connected") {
      this.latest = neutralControls;
      if (status === "disconnected") this.transport = null;
    }
    this.statusListener?.(status, detail, mode);
  }
}
