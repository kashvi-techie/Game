"use client";

import { useEffect, useState } from "react";
import { useControllerStore } from "@/lib/state/controllerStore";
import { getInputSource } from "./controllerHub";
import { InputManager } from "./InputManager";

export function useInput(enabled: boolean) {
  const inputKind = useControllerStore((state) => state.inputKind);
  const [manager] = useState(() => new InputManager(getInputSource(useControllerStore.getState().inputKind)));

  useEffect(() => {
    manager.setSource(getInputSource(inputKind));
  }, [inputKind, manager]);

  useEffect(() => {
    if (!enabled) {
      manager.stop();
      return;
    }

    manager.start();
    return () => manager.stop();
  }, [enabled, manager]);

  return manager;
}
