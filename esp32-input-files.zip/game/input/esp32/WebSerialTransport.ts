import type { LineTransport, TransportHandlers } from "./LineTransport";

/* Minimal Web Serial typings: TypeScript's lib.dom does not ship them, and we avoid an extra dependency. */
interface SerialPortLike {
  readable: ReadableStream<Uint8Array> | null;
  open(options: { baudRate: number }): Promise<void>;
  close(): Promise<void>;
}
interface SerialLike {
  requestPort(): Promise<SerialPortLike>;
  addEventListener(type: "disconnect", listener: (event: Event) => void): void;
  removeEventListener(type: "disconnect", listener: (event: Event) => void): void;
}

const BAUD_RATE = 115200;
/** Safety valve: if the device never sends a newline, do not buffer forever. */
const MAX_LINE_LENGTH = 1024;

function getSerial(): SerialLike | null {
  if (typeof navigator === "undefined") return null;
  return (navigator as unknown as { serial?: SerialLike }).serial ?? null;
}

export function isWebSerialSupported() {
  return getSerial() !== null;
}

export class WebSerialTransport implements LineTransport {
  readonly kind = "serial" as const;

  private port: SerialPortLike | null = null;
  private reader: ReadableStreamDefaultReader<string> | null = null;
  private pipeDone: Promise<void> | null = null;
  private userClosing = false;

  constructor(private readonly handlers: TransportHandlers) {}

  private readonly onPortDisconnect = (event: Event) => {
    // Fired by the browser when the USB device is physically unplugged.
    if (event.target === this.port) void this.teardown("ESP32 unplugged");
  };

  /** Must be called from a user gesture (button click): requestPort() shows the browser's port chooser. */
  async connect() {
    const serial = getSerial();
    if (!serial) {
      this.handlers.onStatus("disconnected", "Web Serial is not supported in this browser (use Chrome or Edge).");
      return;
    }

    this.handlers.onStatus("connecting");
    this.userClosing = false;

    try {
      const port = await serial.requestPort();
      await port.open({ baudRate: BAUD_RATE });
      if (!port.readable) throw new Error("Serial port is not readable");

      this.port = port;
      serial.addEventListener("disconnect", this.onPortDisconnect);

      // bytes -> text. pipeTo() lets us cancel cleanly later.
      const decoder = new TextDecoderStream();
      this.pipeDone = port.readable.pipeTo(decoder.writable as unknown as WritableStream<Uint8Array>).catch(() => {});
      this.reader = decoder.readable.getReader();

      this.handlers.onStatus("connected");
      void this.readLoop(this.reader);
    } catch (error) {
      await this.teardown(describeConnectError(error));
    }
  }

  async disconnect() {
    this.userClosing = true;
    await this.teardown();
  }

  private async readLoop(reader: ReadableStreamDefaultReader<string>) {
    let buffer = "";
    let failure: string | undefined;

    try {
      for (;;) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += value;

        let newline = buffer.indexOf("\n");
        while (newline !== -1) {
          const line = buffer.slice(0, newline).replace(/\r$/, "");
          buffer = buffer.slice(newline + 1);
          if (line) this.handlers.onLine(line);
          newline = buffer.indexOf("\n");
        }
        if (buffer.length > MAX_LINE_LENGTH) buffer = "";
      }
    } catch (error) {
      failure = error instanceof Error ? error.message : "Serial read error";
    }

    // Loop ended on its own (device lost / read error) rather than via disconnect().
    if (!this.userClosing && this.port) await this.teardown(failure ?? "Serial connection closed");
  }

  private async teardown(detail?: string) {
    const port = this.port;
    const reader = this.reader;
    this.port = null;
    this.reader = null;
    getSerial()?.removeEventListener("disconnect", this.onPortDisconnect);

    try {
      await reader?.cancel();
    } catch {
      /* already closed */
    }
    await this.pipeDone;
    this.pipeDone = null;
    try {
      await port?.close();
    } catch {
      /* already closed / unplugged */
    }

    this.handlers.onStatus("disconnected", detail);
  }
}

function describeConnectError(error: unknown): string | undefined {
  if (error instanceof DOMException) {
    // User dismissed the port chooser: not an error worth showing.
    if (error.name === "NotFoundError") return undefined;
    if (error.name === "InvalidStateError" || error.name === "NetworkError") {
      return "Could not open the port. Is it already in use (Arduino IDE / serial monitor)?";
    }
  }
  return error instanceof Error ? error.message : "Could not connect to ESP32";
}
