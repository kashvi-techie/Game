import type { LineTransport, TransportHandlers } from "./LineTransport";

const SEND_INTERVAL_MS = 20; // ~50 Hz, similar to what a real sketch would send

type MockSample = { x: number; y: number; button: boolean };

declare global {
  interface Window {
    /** Dev helper, only present while the simulated ESP32 is connected. */
    __esp32Mock?: {
      /** Send one sample (object) or a raw line (string) exactly as the ESP32 would. Pauses the demo pattern. */
      send: (sample: MockSample | string) => void;
      /** Resume the automatic demo pattern. */
      demo: () => void;
    };
  }
}

/**
 * Simulated ESP32. Emits the same newline-delimited JSON a real board would, so the parser,
 * normalizer and input adapter are exercised exactly like real hardware.
 */
export class MockTransport implements LineTransport {
  readonly kind = "mock" as const;

  private timer: ReturnType<typeof setInterval> | null = null;
  private startedAt = 0;
  private demoActive = true;

  constructor(private readonly handlers: TransportHandlers) {}

  async connect() {
    this.handlers.onStatus("connecting");
    await new Promise((resolve) => setTimeout(resolve, 350)); // feel like a real handshake
    this.startedAt = performance.now();
    this.demoActive = true;

    this.timer = setInterval(() => {
      if (this.demoActive) this.emit(this.demoSample((performance.now() - this.startedAt) / 1000));
    }, SEND_INTERVAL_MS);

    window.__esp32Mock = {
      send: (sample) => {
        this.demoActive = false;
        if (typeof sample === "string") this.handlers.onLine(sample);
        else this.emit(sample);
      },
      demo: () => {
        this.demoActive = true;
      },
    };

    this.handlers.onStatus("connected");
  }

  async disconnect() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    delete window.__esp32Mock;
    this.handlers.onStatus("disconnected");
  }

  private emit(sample: MockSample) {
    this.handlers.onLine(JSON.stringify(sample));
  }

  /** Gentle S-curves with the stick held forward; button (boost) pressed for ~1s every 8s. */
  private demoSample(t: number): MockSample {
    return {
      x: Math.round(2048 + 1900 * Math.sin(t * 0.8)),
      y: 100, // pushed (almost) fully forward
      button: t % 8 > 7,
    };
  }
}
