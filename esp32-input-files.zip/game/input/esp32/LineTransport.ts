export type TransportStatus = "disconnected" | "connecting" | "connected";

export type TransportHandlers = {
  /** One complete text line (without the newline). */
  onLine: (line: string) => void;
  /** `detail` carries a human-readable reason on disconnect/error. */
  onStatus: (status: TransportStatus, detail?: string) => void;
};

/** Anything that can deliver newline-delimited text lines: real serial port, mock generator, later WebSocket... */
export interface LineTransport {
  readonly kind: "serial" | "mock";
  connect(): Promise<void>;
  disconnect(): Promise<void>;
}
