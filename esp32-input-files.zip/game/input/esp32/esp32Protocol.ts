import { type ControllerControls, neutralControls } from "../ControllerInputSource";

/**
 * Wire format (one JSON object per line, newline-terminated):
 *   {"x":2048,"y":2048,"button":false}
 * x / y : raw 12-bit ADC values, 0..4095, ~2048 at rest
 * button: boolean (0/1 also accepted); optional, defaults to false
 */
export type JoystickSample = { x: number; y: number; button: boolean };

export type JoystickCalibration = {
  /** ADC value at rest. */
  center: number;
  /** Highest ADC value (ESP32 is 12-bit by default). */
  adcMax: number;
  /** Fraction of full deflection (0..1) ignored around the center. */
  deadZone: number;
  /** Flip left/right if the stick is mounted the other way round. */
  invertX: boolean;
  /**
   * Y axis maps to throttle/brake. By default a LOW raw y (stick pushed "up"/forward) is throttle
   * and a HIGH raw y is brake. Flip if your module is wired the other way.
   */
  invertY: boolean;
};

export const DEFAULT_JOYSTICK_CALIBRATION: JoystickCalibration = {
  center: 2048,
  adcMax: 4095,
  deadZone: 0.12,
  invertX: false,
  invertY: false,
};

/** Returns null for anything that is not a valid sample (boot logs, partial lines, junk). */
export function parseControllerLine(line: string): JoystickSample | null {
  const trimmed = line.trim();
  // ESP32 prints boot/debug text on the same UART; ignore anything that is not a JSON object.
  if (trimmed.length === 0 || trimmed[0] !== "{") return null;

  let data: unknown;
  try {
    data = JSON.parse(trimmed);
  } catch {
    return null;
  }
  if (typeof data !== "object" || data === null) return null;

  const { x, y, button } = data as Record<string, unknown>;
  if (typeof x !== "number" || typeof y !== "number") return null;
  if (!Number.isFinite(x) || !Number.isFinite(y)) return null;

  return { x, y, button: button === true || button === 1 };
}

/** raw ADC -> -1..+1 with dead zone. The dead zone is rescaled so output ramps smoothly from 0 at its edge. */
export function normalizeAxis(raw: number, calibration: JoystickCalibration): number {
  const { center, adcMax, deadZone } = calibration;
  const span = raw >= center ? adcMax - center : center;
  const linear = Math.max(-1, Math.min(1, (raw - center) / span));
  const magnitude = Math.abs(linear);
  if (magnitude <= deadZone) return 0;
  return Math.sign(linear) * ((magnitude - deadZone) / (1 - deadZone));
}

/** JoystickSample -> the same InputState the keyboard produces. */
export function joystickToInputState(
  sample: JoystickSample,
  calibration: JoystickCalibration = DEFAULT_JOYSTICK_CALIBRATION,
): ControllerControls {
  const steering = normalizeAxis(sample.x, calibration) * (calibration.invertX ? -1 : 1);
  // Raw y grows downward (like screen coordinates): negative = pushed forward = throttle.
  const forward = -normalizeAxis(sample.y, calibration) * (calibration.invertY ? -1 : 1);

  return {
    ...neutralControls,
    steering,
    throttle: Math.max(0, forward),
    brake: Math.max(0, -forward),
    action1: sample.button,
  };
}
